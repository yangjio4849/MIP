#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author: ymj <ymj155@gmail.com>
Time: 2019/11/20 15:00
File:
Introduction:
"""
__version__ = 1.0

import matplotlib as mpl
mpl.use('Agg')
# auto layout fit the figure
# mpl.rc('figure', autolayout=True)

import matplotlib.pyplot as plt
import numpy as np
import os

# 字体设置
plt.rcParams['font.sans-serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 24


def ana_trans_trace_dat(filename):
    """
    analysis data from transoptic_e_omp
    :param filename: 'CRTA-tensor-e.txt','RTA-tensor-e.txt'
    :returns: all_data skip the first line of name,
            data_title,
            data_tensor
    """
    # 读入数据，按列分配
    # tensor (1-1),(3-3)
    # data_name
    """
    emu(eV)                             1 
    n(10^20/cm3)                        2
    DOS                                 3
    intDOS                              4
    tau                                 5
    |vk|(m/s)                           6
    sigma                               7
    ke                                  8
    L(1E-8V2K-2)                        9  
    S(uV/K)                             10
    PF                                  11  
    EFF(10^-20 W^5/3 m s^-1/3 K^-2)     12
    """

    # A,B,C,D,E,F,G,H,I,J,K = np.loadtxt(filename, skiprows=1,unpack=True)
    all_data = np.loadtxt(filename, skiprows=1, unpack=True)
    data_title = {
        'e_title': 'E (eV)',
        'n_title': 'n ($\mathregular{10^{20} \  cm^{-3}}$)',
        'dos_tilte': 'DOS',
        'intdos_tilte': 'intDOS',
        'tau_title': 'tau(1E-14s)',
        'vk_title': '|vk|(m/s)',
        'sigma_title': r'$\mathregular{\sigma}$' + ' (S/m)',
        'ke_title': 'ke(Wm-1K-1)',
        'L_title': 'L(1E-8V2K-2)',
        'S_title': r'S ($\mathregular{\mu}$V/K )',
        'PF_title': 'PF ($\mathregular{ 1E^{-4}Wm^{-1}K^{-2} }$)',
        'EFF_title': 'EFF ($\mathregular{ 10^{-20}W^{5/3}ms^{-1/3}K^{-2} }$)',
    }

    return all_data, data_title


def plot_seeback_trace(infile='CRTA-tensor-e.txt', suptitle='', figpath='', output='Seeback.jpg'):
    """
    plot Seeback and sigma along verse n
    :param infile: RTA-tensor-e.txt form TransOpt
    :param suptitle:
    :param figpath:
    :return: png file
    """
    all_data, data_title = ana_trans_trace_dat(infile)
    fig = plt.figure(figsize=(17.8, 8.9))
    ax1 = plt.subplot(1, 2, 1)
    # S n
    ax1.plot(all_data[1], all_data[9])

    ax1.set_xlabel(data_title['n_title'])
    ax1.set_ylabel(data_title['S_title'])
    # ax1.legend()
    # ax1.tick_params()


    ax2 = plt.subplot(1, 2, 2)
    # S e
    ax2.plot(all_data[0], all_data[9])
    ax2.set_xlabel('$\mathregular{E-E_F\ (eV)}$')

    plt.tight_layout()
    fig.suptitle(suptitle)
    figure_name = os.path.join(figpath, output)
    plt.savefig(figure_name, dpi=300, bbox_inches='tight')
    plt.close()


def plot_sigma_trace(infile='RTA-tensor-e.txt', suptitle='', figpath='', output='Sigma.jpg'):
    """
    plot sigma verse n e
    for 2D n times 30 angstrom
    :param infile: RTA-tensor-e.txt form TransOpt
    :param suptitle:
    :param figpath:
    :param lz:
    :return: png file
    """
    all_data, data_title = ana_trans_trace_dat(infile)
    fig = plt.figure(figsize=(17.8, 8.9))
    ax1 = plt.subplot(1, 2, 1)
    # sigma n
    ax1.plot(all_data[1], all_data[6])

    ax1.set_xlabel(data_title['n_title'])
    ax1.set_ylabel(data_title['sigma_title'])


    # y = all_data[2][(x > -100) & (x < 100)]

    ax2 = plt.subplot(1, 2, 2)
    # S em
    ax2.plot(all_data[0], all_data[6])

    ax2.set_xlabel('$\mathregular{E-E_F\ (eV)}$')


    plt.tight_layout()
    fig.suptitle(suptitle)

    figure_name = os.path.join(figpath, output)
    plt.savefig(figure_name, dpi=300, bbox_inches='tight')
    plt.close()


def plot_pf_trace(infile='RTA-tensor-e.txt', suptitle='', figpath='', output='PF.jpg'):
    """
    plot PF verse n e
    :param infile: RTA-tensor-e.txt form TransOpt
    :param suptitle:
    :param figpath:
    :return: png file
    """
    all_data, data_title = ana_trans_trace_dat(infile)
    fig = plt.figure(figsize=(17.8, 8.9))
    ax1 = plt.subplot(1, 2, 1)
    # S n
    ax1.plot(all_data[1], all_data[10])

    ax1.set_xlabel(data_title['n_title'])
    ax1.set_ylabel(data_title['PF_title'])

    ax2 = plt.subplot(1, 2, 2)
    # PF e
    ax2.plot(all_data[0], all_data[10])
    ax2.set_xlabel('$\mathregular{E-E_F\ (eV)}$')

    plt.tight_layout()
    fig.suptitle(suptitle)
    figure_name = os.path.join(figpath, output)
    plt.savefig(figure_name, dpi=300, bbox_inches='tight')
    plt.close()


def plot_n_e(infile='CRTA-tensor-e.txt', suptitle='', figpath='', output='N_E.jpg'):
    all_data, data_title = ana_trans_trace_dat(infile)

    fig = plt.figure(figsize=(8.9, 8.9))
    ax1 = plt.subplot(1, 1, 1)
    # n e
    ax1.plot(all_data[0], all_data[1])
    ax1.set_ylabel(data_title['n_title'])
    ax1.set_xlabel('$\mathregular{E-E_F\ (eV)}$')

    plt.tight_layout()
    fig.suptitle(suptitle)
    figure_name = os.path.join(figpath, output)
    plt.savefig(figure_name, dpi=300, bbox_inches='tight')
    plt.close()


if __name__ == '__main__':
    figpath=''
    # download_RTA-trace-e_ntype.txt
    ntype_file='download_CRTA-trace-e_ntype.txt'
    plot_seeback_trace(infile=ntype_file, figpath=figpath, output='n_Seeback.jpg')
    plot_sigma_trace(infile=ntype_file, figpath=figpath, output='n_Sigma.jpg')
    plot_pf_trace(infile=ntype_file, figpath=figpath, output='n_PF.jpg')
    plot_n_e(infile=ntype_file, figpath=figpath, output='n_N_E.jpg')
    # download_RTA-trace-e_ptype.txt
    ptype_file='download_CRTA-trace-e_ptype.txt'
    plot_seeback_trace(infile=ptype_file, figpath=figpath, output='p_Seeback.jpg')
    plot_sigma_trace(infile=ptype_file, figpath=figpath, output='p_Sigma.jpg')
    plot_pf_trace(infile=ptype_file, figpath=figpath, output='p_PF.jpg')
    plot_n_e(infile=ptype_file, figpath=figpath, output='p_N_E.jpg')
    print('plot over')


