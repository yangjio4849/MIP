#!/usr/bin/env python
import os
import numpy as np
# get element list and 1, 2-3
pos_file = 'POSCAR'
with open(pos_file, 'r') as fpos:
    pos = fpos.readlines()
    element = pos[5].split()  # elements
    atom_num = pos[6].split()
    atom_num = np.array(atom_num, dtype=int)
    atom_range = [ i+1 for i in range(sum(atom_num))]
    for i,j in enumerate(atom_num):
        ele_range = atom_range[:j]
        start_range = ele_range[0]
        end_range = ele_range[-1]
        print(element[i], str(start_range)+'-'+str(end_range))
        os.system('pyband --occ ' + str(start_range)+'-'+str(end_range) +
         ' --occL --occLC_cbar_pos="right" --occLC_cbar_vmax="1.0" --occLC_cbar_vmin="0.0" --output=band_par_'+ element[i] +'.png' +
         ' -s 10 6 -y -5 5')
        del atom_range[:j]
