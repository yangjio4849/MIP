#PBS -N myjob
#PBS -l nodes=2:ppn=12
#PBS -S /bin/bash
#PBS -q pool2

# This job's working directory
cd $PBS_O_WORKDIR    

# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`

echo This job has allocated $NPROCS nodes

# Run the parallel MPI executable a.out

#---------------------------------------------------------
#!/bin/bash

#define your grids for BZ, 
n=11

 nx=$n-1
 ny=$n-1
 nz=$n-1

 N=`echo "($nx+1)*($ny+1)*($nz+1)" | bc -l`


 echo BZ: grids: $nx2 $ny2 $nz2, total KPOINTS: $N
 echo Now generating KPOINTS file ...
 echo "Kpoints for BZ" > KPOINTS
 echo "$N" >> KPOINTS
 echo "rec" >> KPOINTS

 for((x=0;x<=$nx;x++))
 do
     for((y=0;y<=$ny;y++))
     do
       for((z=0;z<=$nz;z++))
       do
           tz=`echo "$z/($nz)" | bc -l`
           ty=`echo "$y/($ny)" | bc -l`
           tx=`echo "$x/($nx)" | bc -l`
           echo "${tx:0:4} ${ty:0:4} ${tz:0:4} 1.0" >> KPOINTS
       done
     done
 done



  echo " Runing VASP, make sure next line is correct"
mpiexec -np $NPROCS --mca btl openib,self,sm /home/bin/vasp.4.6.34 > result


