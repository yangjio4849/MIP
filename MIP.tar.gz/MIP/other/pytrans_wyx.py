#!/usr/bin/env python
#-*- coding:utf-8 -*-
"""
Author: ymj <ymj155@gmail.com>
Time: 2020/2/28 19:41
File: pytrans_S_Sigma_PF_gap2txt.py
Introduction: 
"""
__version__ = 1.0

# import matplotlib as mpl
# mpl.use('Agg')
import re

import matplotlib.pyplot as plt
import numpy as np
import os


def ana_trans_trace_dat_prarg(n_type, p_type):
    """
    analysis data from transoptic_e_omp
    :param filename: 'CRTA-tensor-e.txt','RTA-tensor-e.txt'
    :returns: all_data skip the first line of name,
            data_title,
            data_tensor
    """
    # 读入数据，按列分配
    # tensor (1-1),(3-3)
    # data_name
    """
    emu(eV)                             1 
    n(10^20/cm3)                        2
    DOS                                 3
    intDOS                              4
    tau                                 5
    |vk|(m/s)                           6
    sigma                               7
    ke                                  8
    L(1E-8V2K-2)                        9  
    S(uV/K)                             10
    PF                                  11  
    EFF(10^-20 W^5/3 m s^-1/3 K^-2)     12
    """

    all_data_n = np.loadtxt(n_type, skiprows=1, unpack=True)
    n_type_arg = np.argwhere(all_data_n[1] > 0.999)[0]

    all_data_p = np.loadtxt(p_type, skiprows=1, unpack=True)
    p_type_arg = np.argwhere(all_data_p[1] < -0.999)[-1]
    print(int(n_type_arg + 2) , int(p_type_arg + 2), sep='\n')


if __name__ == '__main__':
    #

    filename_ntype = 'download_CRTA-trace-e_ntype.txt'
    filename_ptype = 'download_CRTA-trace-e_ptype.txt'

    ana_trans_trace_dat_prarg(n_type=filename_ntype, p_type=filename_ptype)

