#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Author: ymj <ymj155@gmai.com>
Time: 2020/12/20 下午7:59
File: pyplot_eff_3d_trace.py
Introduction:
"""
__version__ = 0.1

import matplotlib as mpl
mpl.use('Agg')
# auto layout fit the figure
# mpl.rc('figure', autolayout=True)

import matplotlib.pyplot as plt
import numpy as np
import os

# 字体设置
plt.rcParams['font.sans-serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 24


def analysis_eff_trace(filename='CRTA-tensor-e_ntype_700.txt', figure_name='', ptype=1):
    """analysis EEF"""
    # 读入数据，按列分配
    """
    # tensor (1-1),(3-3)
    emu(eV)                                     1 
    n(10^20/cm3)                                2
    sigma(1,1)-(3,3)                            3-11
    ke(1,1)-(3,3)                               12-20
    L(1E-8V2K-2)(1,1)-(3,3)                     21-29  
    S(uV/K)(1,1)-(3,3)                          30-38
    PF(1,1)-(3,3)                               39-47   
    EFF(10^-20 W^5/3 m s^-1/3 K^-2)(1,1)-(3,3)  48-56
    """

    all_data = np.loadtxt(filename, skiprows=1, unpack=True)
    data_title = {
        'e_title': 'emu (eV)',
        'n_title': 'n ($\mathregular{10^{20} \ cm^{-3}}$)',
        'dos_tilte': 'DOS',
        'intdos_tilte': 'intDOS',
        'tau_title': 'tau(1E-14s)',
        'vk_title': '|vk|(m/s)',
        'sigma_title': r'$\mathregular{\sigma}$' + '  (S/m)',
        'ke_title': 'ke(Wm-1K-1)',
        'L_title': 'L(1E-8V2K-2)',
        'S_title': r'S ($\mathregular{\mu}$V/K)',
        'PF_title': 'PF ($\mathregular{10^{-4}Wm^{-1}K^{-2}}$ )',
        'EFF_title': 'EFF ($\mathregular{10^{-20}W^{5/3}ms^{-1/3}K^{-2}}$)',
    }

    # max EFF
    # EFF_X: all_data[47],
    # EFF_y: all_data[51]

    eff_arg = np.argmax(all_data[11])
    eff = all_data[11][eff_arg]

    n_max =  all_data[1][eff_arg]

    plt.figure(figsize=(17.8, 8.9))
    # EFF
    plt.plot(all_data[1]*ptype, all_data[11], c='y', label='$\mathregular{EFF_{xx}}$')
    plt.scatter(n_max*ptype, eff)
    plt.xscale('log')

    plt.xlabel(data_title['n_title'])
    plt.ylabel(data_title['EFF_title'])

    plt.legend()
    plt.tight_layout()

    # plt.show()
    plt.savefig(figure_name, bbox_inches='tight')  # dpi=600,
    plt.close('all')

    return n_max, eff


if __name__ == '__main__':

    # 700K
    file_path = ''

    filename = os.path.join(file_path, 'download_CRTA-trace-e_ntype.txt')
    figure_name = os.path.join(file_path, 'EFF_n_700.jpg')
    n_max, n_eff = analysis_eff_trace(filename=filename, figure_name=figure_name)


    filename = os.path.join(file_path, 'download_CRTA-trace-e_ptype.txt')
    figure_name = os.path.join(file_path, 'EFF_p_700.jpg')
    p_max, p_eff = analysis_eff_trace(filename=filename, figure_name=figure_name, ptype=-1)
    print(n_max, n_eff, p_max, p_eff, sep=',')


